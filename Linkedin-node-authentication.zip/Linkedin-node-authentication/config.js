module.exports = {
    'linkedinAuth': {
      'clientID': '86yubwdpnz4b73', // your App ID
      'clientSecret': '7WZZwGA9AsArJqRJ', // your App Secret
      'callbackURL': 'http://127.0.0.1:3000/auth/linkedin/callback'
      
      
    }
  }